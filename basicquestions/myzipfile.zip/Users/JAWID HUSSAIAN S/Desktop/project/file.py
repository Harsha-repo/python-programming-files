import os
filename = input('enter your file name : ')
if os.path.isfile(filename):

    print(os.path.isfile(filename))
    print('the file is opened')
else :
	print('the file is not present ')